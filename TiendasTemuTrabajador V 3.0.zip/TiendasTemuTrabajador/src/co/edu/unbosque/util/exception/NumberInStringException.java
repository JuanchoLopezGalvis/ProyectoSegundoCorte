package co.edu.unbosque.util.exception;

public class NumberInStringException extends Exception {

	public NumberInStringException() {

	super ("Aca solo van letras, intente denuevo mas tarde");
	}
}
