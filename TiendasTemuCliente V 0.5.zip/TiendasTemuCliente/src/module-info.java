/**
 * 
 */
/**
 * 
 */
module TiendasTemuCliente {
	requires java.desktop;
}