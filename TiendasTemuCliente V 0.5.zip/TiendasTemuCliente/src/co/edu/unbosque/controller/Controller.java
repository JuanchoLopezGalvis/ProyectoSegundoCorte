package co.edu.unbosque.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import javax.swing.JOptionPane;

import co.edu.unbosque.model.*;
import co.edu.unbosque.view.*;

public class Controller implements ActionListener {

	private ModelFacade mf;
	private ViewFacade vf;
	private Properties prop;

	public Controller() {
		mf = new ModelFacade();
		vf = new ViewFacade();
	}

	public void run() {

		prop = new Properties();
		vf.getVp().setVisible(true);
		asignarLecotres();
	}

	public void asignarLecotres() {

		vf.getVp().getPp().getIngresar().addActionListener(this);
		vf.getVp().getPp().getIngresar().setActionCommand("btnIngresar");

		vf.getVp().getPp().getCheckEspañol().addActionListener(this);
		vf.getVp().getPp().getCheckEspañol().setActionCommand("checkEspañol");

		vf.getVp().getPp().getCheckIngles().addActionListener(this);
		vf.getVp().getPp().getCheckIngles().setActionCommand("checkIngles");

		vf.getVpr().getMenuCarrito().addMouseListener(new MouseListener() {

			@Override
			public void mouseReleased(MouseEvent e) {
			}

			@Override
			public void mousePressed(MouseEvent e) {
			}

			@Override
			public void mouseExited(MouseEvent e) {
			}

			@Override
			public void mouseEntered(MouseEvent e) {
			}

			@Override
			public void mouseClicked(MouseEvent e) {
				JOptionPane.showMessageDialog(null, prop.getProperty("tiendastemucliente.ventanaprincipal.ingresar"));

			}
		});

		vf.getVpr().getMenuIdioma().addMouseListener(new MouseListener() {
			@Override
			public void mouseReleased(MouseEvent e) {
			}

			@Override
			public void mousePressed(MouseEvent e) {
			}

			@Override
			public void mouseExited(MouseEvent e) {
			}

			@Override
			public void mouseEntered(MouseEvent e) {
			}

			@Override
			public void mouseClicked(MouseEvent e) {
				vf.getVsi().setVisible(true);
			}
		});

		vf.getVpr().getMenuSalir().addMouseListener(new MouseListener() {

			@Override
			public void mouseReleased(MouseEvent e) {
			}

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseExited(MouseEvent e) {
			}

			@Override
			public void mouseEntered(MouseEvent e) {
			}

			@Override
			public void mouseClicked(MouseEvent e) {
				int opc = JOptionPane.showConfirmDialog(null,
						prop.getProperty("tiendastemucliente.barramenu.textosalida"), "Salir programa",
						JOptionPane.YES_NO_OPTION);
				if (opc == 0) {
					System.exit(0);
				}
			}
		});

		// VENTANA BAÑO

		vf.getVpb().getMenuCarrito().addMouseListener(new MouseListener() {

			@Override
			public void mouseReleased(MouseEvent e) {
			}

			@Override
			public void mousePressed(MouseEvent e) {
			}

			@Override
			public void mouseExited(MouseEvent e) {
			}

			@Override
			public void mouseEntered(MouseEvent e) {
			}

			@Override
			public void mouseClicked(MouseEvent e) {
				JOptionPane.showMessageDialog(null, prop.getProperty("tiendastemucliente.ventanaprincipal.ingresar"));

			}
		});

		vf.getVpb().getMenuIdioma().addMouseListener(new MouseListener() {
			@Override
			public void mouseReleased(MouseEvent e) {
			}

			@Override
			public void mousePressed(MouseEvent e) {
			}

			@Override
			public void mouseExited(MouseEvent e) {
			}

			@Override
			public void mouseEntered(MouseEvent e) {
			}

			@Override
			public void mouseClicked(MouseEvent e) {
				vf.getVsi().setVisible(true);
			}
		});

		vf.getVpb().getMenuSalir().addMouseListener(new MouseListener() {

			@Override
			public void mouseReleased(MouseEvent e) {
			}

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseExited(MouseEvent e) {
			}

			@Override
			public void mouseEntered(MouseEvent e) {
			}

			@Override
			public void mouseClicked(MouseEvent e) {
				int opc = JOptionPane.showConfirmDialog(null,
						prop.getProperty("tiendastemucliente.barramenu.textosalida"), "Salir programa",
						JOptionPane.YES_NO_OPTION);
				if (opc == 0) {
					System.exit(0);
				}
			}
		});

		// VENTANA COCINA

		vf.getVpc().getMenuCarrito().addMouseListener(new MouseListener() {

			@Override
			public void mouseReleased(MouseEvent e) {
			}

			@Override
			public void mousePressed(MouseEvent e) {
			}

			@Override
			public void mouseExited(MouseEvent e) {
			}

			@Override
			public void mouseEntered(MouseEvent e) {
			}

			@Override
			public void mouseClicked(MouseEvent e) {
				JOptionPane.showMessageDialog(null, prop.getProperty("tiendastemucliente.ventanaprincipal.ingresar"));

			}
		});

		vf.getVpc().getMenuIdioma().addMouseListener(new MouseListener() {
			@Override
			public void mouseReleased(MouseEvent e) {
			}

			@Override
			public void mousePressed(MouseEvent e) {
			}

			@Override
			public void mouseExited(MouseEvent e) {
			}

			@Override
			public void mouseEntered(MouseEvent e) {
			}

			@Override
			public void mouseClicked(MouseEvent e) {
				vf.getVsi().setVisible(true);
			}
		});

		vf.getVpc().getMenuSalir().addMouseListener(new MouseListener() {

			@Override
			public void mouseReleased(MouseEvent e) {
			}

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseExited(MouseEvent e) {
			}

			@Override
			public void mouseEntered(MouseEvent e) {
			}

			@Override
			public void mouseClicked(MouseEvent e) {
				int opc = JOptionPane.showConfirmDialog(null,
						prop.getProperty("tiendastemucliente.barramenu.textosalida"), "Salir programa",
						JOptionPane.YES_NO_OPTION);
				if (opc == 0) {
					System.exit(0);
				}
			}
		});

		// VENTANA JUGUETE
		vf.getVpj().getMenuCarrito().addMouseListener(new MouseListener() {

			@Override
			public void mouseReleased(MouseEvent e) {
			}

			@Override
			public void mousePressed(MouseEvent e) {
			}

			@Override
			public void mouseExited(MouseEvent e) {
			}

			@Override
			public void mouseEntered(MouseEvent e) {
			}

			@Override
			public void mouseClicked(MouseEvent e) {
				JOptionPane.showMessageDialog(null, prop.getProperty("tiendastemucliente.ventanaprincipal.ingresar"));

			}
		});

		vf.getVpj().getMenuIdioma().addMouseListener(new MouseListener() {
			@Override
			public void mouseReleased(MouseEvent e) {
			}

			@Override
			public void mousePressed(MouseEvent e) {
			}

			@Override
			public void mouseExited(MouseEvent e) {
			}

			@Override
			public void mouseEntered(MouseEvent e) {
			}

			@Override
			public void mouseClicked(MouseEvent e) {
				vf.getVsi().setVisible(true);
			}
		});

		vf.getVpj().getMenuSalir().addMouseListener(new MouseListener() {

			@Override
			public void mouseReleased(MouseEvent e) {
			}

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseExited(MouseEvent e) {
			}

			@Override
			public void mouseEntered(MouseEvent e) {
			}

			@Override
			public void mouseClicked(MouseEvent e) {
				int opc = JOptionPane.showConfirmDialog(null,
						prop.getProperty("tiendastemucliente.barramenu.textosalida"), "Salir programa",
						JOptionPane.YES_NO_OPTION);
				if (opc == 0) {
					System.exit(0);
				}
			}
		});

		// VENTANA ROPA
		vf.getVpro().getMenuCarrito().addMouseListener(new MouseListener() {

			@Override
			public void mouseReleased(MouseEvent e) {
			}

			@Override
			public void mousePressed(MouseEvent e) {
			}

			@Override
			public void mouseExited(MouseEvent e) {
			}

			@Override
			public void mouseEntered(MouseEvent e) {
			}

			@Override
			public void mouseClicked(MouseEvent e) {
				JOptionPane.showMessageDialog(null, prop.getProperty("tiendastemucliente.ventanaprincipal.ingresar"));

			}
		});

		vf.getVpro().getMenuIdioma().addMouseListener(new MouseListener() {
			@Override
			public void mouseReleased(MouseEvent e) {
			}

			@Override
			public void mousePressed(MouseEvent e) {
			}

			@Override
			public void mouseExited(MouseEvent e) {
			}

			@Override
			public void mouseEntered(MouseEvent e) {
			}

			@Override
			public void mouseClicked(MouseEvent e) {
				vf.getVsi().setVisible(true);
			}
		});

		vf.getVpro().getMenuSalir().addMouseListener(new MouseListener() {

			@Override
			public void mouseReleased(MouseEvent e) {
			}

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseExited(MouseEvent e) {
			}

			@Override
			public void mouseEntered(MouseEvent e) {
			}

			@Override
			public void mouseClicked(MouseEvent e) {
				int opc = JOptionPane.showConfirmDialog(null,
						prop.getProperty("tiendastemucliente.barramenu.textosalida"), "Salir programa",
						JOptionPane.YES_NO_OPTION);
				if (opc == 0) {
					System.exit(0);
				}
			}
		});
		// VENTANA ELECTRO
		vf.getVpe().getMenuCarrito().addMouseListener(new MouseListener() {

			@Override
			public void mouseReleased(MouseEvent e) {
			}

			@Override
			public void mousePressed(MouseEvent e) {
			}

			@Override
			public void mouseExited(MouseEvent e) {
			}

			@Override
			public void mouseEntered(MouseEvent e) {
			}

			@Override
			public void mouseClicked(MouseEvent e) {
				JOptionPane.showMessageDialog(null, prop.getProperty("tiendastemucliente.ventanaprincipal.ingresar"));

			}
		});

		vf.getVpe().getMenuIdioma().addMouseListener(new MouseListener() {
			@Override
			public void mouseReleased(MouseEvent e) {
			}

			@Override
			public void mousePressed(MouseEvent e) {
			}

			@Override
			public void mouseExited(MouseEvent e) {
			}

			@Override
			public void mouseEntered(MouseEvent e) {
			}

			@Override
			public void mouseClicked(MouseEvent e) {
				vf.getVsi().setVisible(true);
			}
		});

		vf.getVpe().getMenuSalir().addMouseListener(new MouseListener() {

			@Override
			public void mouseReleased(MouseEvent e) {
			}

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseExited(MouseEvent e) {
			}

			@Override
			public void mouseEntered(MouseEvent e) {
			}

			@Override
			public void mouseClicked(MouseEvent e) {
				int opc = JOptionPane.showConfirmDialog(null,
						prop.getProperty("tiendastemucliente.barramenu.textosalida"), "Salir programa",
						JOptionPane.YES_NO_OPTION);
				if (opc == 0) {
					System.exit(0);
				}
			}
		});
		// VENTANA PAPELERIA
		vf.getVpp().getMenuCarrito().addMouseListener(new MouseListener() {

			@Override
			public void mouseReleased(MouseEvent e) {
			}

			@Override
			public void mousePressed(MouseEvent e) {
			}

			@Override
			public void mouseExited(MouseEvent e) {
			}

			@Override
			public void mouseEntered(MouseEvent e) {
			}

			@Override
			public void mouseClicked(MouseEvent e) {
				JOptionPane.showMessageDialog(null, prop.getProperty("tiendastemucliente.ventanaprincipal.ingresar"));

			}
		});

		vf.getVpp().getMenuIdioma().addMouseListener(new MouseListener() {
			@Override
			public void mouseReleased(MouseEvent e) {
			}

			@Override
			public void mousePressed(MouseEvent e) {
			}

			@Override
			public void mouseExited(MouseEvent e) {
			}

			@Override
			public void mouseEntered(MouseEvent e) {
			}

			@Override
			public void mouseClicked(MouseEvent e) {
				vf.getVsi().setVisible(true);
			}
		});

		vf.getVpp().getMenuSalir().addMouseListener(new MouseListener() {

			@Override
			public void mouseReleased(MouseEvent e) {
			}

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseExited(MouseEvent e) {
			}

			@Override
			public void mouseEntered(MouseEvent e) {
			}

			@Override
			public void mouseClicked(MouseEvent e) {
				int opc = JOptionPane.showConfirmDialog(null,
						prop.getProperty("tiendastemucliente.barramenu.textosalida"), "Salir programa",
						JOptionPane.YES_NO_OPTION);
				if (opc == 0) {
					System.exit(0);
				}
			}
		});
		// VENTANA RECOMEND
		vf.getVpre().getMenuCarrito().addMouseListener(new MouseListener() {

			@Override
			public void mouseReleased(MouseEvent e) {
			}

			@Override
			public void mousePressed(MouseEvent e) {
			}

			@Override
			public void mouseExited(MouseEvent e) {
			}

			@Override
			public void mouseEntered(MouseEvent e) {
			}

			@Override
			public void mouseClicked(MouseEvent e) {
				JOptionPane.showMessageDialog(null, prop.getProperty("tiendastemucliente.ventanaprincipal.ingresar"));

			}
		});

		vf.getVpre().getMenuIdioma().addMouseListener(new MouseListener() {
			@Override
			public void mouseReleased(MouseEvent e) {
			}

			@Override
			public void mousePressed(MouseEvent e) {
			}

			@Override
			public void mouseExited(MouseEvent e) {
			}

			@Override
			public void mouseEntered(MouseEvent e) {
			}

			@Override
			public void mouseClicked(MouseEvent e) {
				vf.getVsi().setVisible(true);
			}
		});

		vf.getVpre().getMenuSalir().addMouseListener(new MouseListener() {

			@Override
			public void mouseReleased(MouseEvent e) {
			}

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseExited(MouseEvent e) {
			}

			@Override
			public void mouseEntered(MouseEvent e) {
			}

			@Override
			public void mouseClicked(MouseEvent e) {
				int opc = JOptionPane.showConfirmDialog(null,
						prop.getProperty("tiendastemucliente.barramenu.textosalida"), "Salir programa",
						JOptionPane.YES_NO_OPTION);
				if (opc == 0) {
					System.exit(0);
				}
			}
		});

		vf.getVsi().getPsi().getCheckEspañol().addActionListener(this);
		vf.getVsi().getPsi().getCheckEspañol().setActionCommand("checkEspañol2");

		vf.getVsi().getPsi().getCheckIngles().addActionListener(this);
		vf.getVsi().getPsi().getCheckIngles().setActionCommand("checkIngles2");

		// VENTANA PRODUCTO
		vf.getVpr().getProductoTodos().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpr().setVisible(false);
				vf.getVpr().setVisible(true);
				vf.getVpr().repaint();

			}
		});

		vf.getVpr().getProductoBanio().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpr().setVisible(false);
				vf.getVpb().setVisible(true);
				vf.getVpb().repaint();

			}
		});

		vf.getVpr().getProductoCocina().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpr().setVisible(false);
				vf.getVpc().setVisible(true);
				vf.getVpc().repaint();

			}
		});

		vf.getVpr().getProductoJuguete().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpr().setVisible(false);
				vf.getVpj().setVisible(true);
				vf.getVpj().repaint();

			}
		});

		vf.getVpr().getProductoRopa().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpr().setVisible(false);
				vf.getVpro().setVisible(true);
				vf.getVpro().repaint();

			}
		});

		vf.getVpr().getProductoElectro().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpr().setVisible(false);
				vf.getVpe().setVisible(true);
				vf.getVpe().repaint();

			}
		});

		vf.getVpr().getProductoPapeleria().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpr().setVisible(false);
				vf.getVpp().setVisible(true);
				vf.getVpp().repaint();

			}
		});

		vf.getVpr().getProductoRecomend().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpr().setVisible(false);
				vf.getVpre().setVisible(true);
				vf.getVpre().repaint();

			}
		});
		vf.getVpr().getProductoTodos().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpr().setVisible(false);
				vf.getVpr().setVisible(true);
				vf.getVpr().repaint();

			}
		});

		vf.getVpr().getProductoBanio().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpr().setVisible(false);
				vf.getVpb().setVisible(true);
				vf.getVpb().repaint();

			}
		});

		vf.getVpr().getProductoCocina().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpr().setVisible(false);
				vf.getVpc().setVisible(true);
				vf.getVpc().repaint();

			}
		});

		vf.getVpr().getProductoJuguete().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpr().setVisible(false);
				vf.getVpj().setVisible(true);
				vf.getVpj().repaint();

			}
		});

		vf.getVpr().getProductoRopa().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpr().setVisible(false);
				vf.getVpro().setVisible(true);
				vf.getVpro().repaint();

			}
		});

		vf.getVpr().getProductoElectro().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpr().setVisible(false);
				vf.getVpe().setVisible(true);
				vf.getVpe().repaint();

			}
		});

		vf.getVpr().getProductoPapeleria().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpr().setVisible(false);
				vf.getVpp().setVisible(true);
				vf.getVpp().repaint();

			}
		});

		vf.getVpr().getProductoRecomend().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpr().setVisible(false);
				vf.getVpre().setVisible(true);
				vf.getVpre().repaint();

			}
		});
		// VENTANA PRODUCTO BAÑO
		vf.getVpb().getProductoTodo().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpb().setVisible(false);
				vf.getVpr().setVisible(true);
				vf.getVpr().repaint();

			}
		});

		vf.getVpb().getProductoBanio().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpb().setVisible(false);
				vf.getVpb().setVisible(true);
				vf.getVpb().repaint();

			}
		});

		vf.getVpb().getProductoCocina().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpb().setVisible(false);
				vf.getVpc().setVisible(true);
				vf.getVpc().repaint();

			}
		});

		vf.getVpb().getProductoJuguete().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpb().setVisible(false);
				vf.getVpj().setVisible(true);
				vf.getVpj().repaint();

			}
		});

		vf.getVpb().getProductoRopa().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpb().setVisible(false);
				vf.getVpro().setVisible(true);
				vf.getVpro().repaint();

			}
		});

		vf.getVpb().getProductoElectro().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpb().setVisible(false);
				vf.getVpe().setVisible(true);
				vf.getVpe().repaint();

			}
		});

		vf.getVpb().getProductoPapeleria().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpb().setVisible(false);
				vf.getVpp().setVisible(true);
				vf.getVpp().repaint();

			}
		});

		vf.getVpb().getProductoRecomend().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpb().setVisible(false);
				vf.getVpre().setVisible(true);
				vf.getVpre().repaint();

			}
		});
		// VENTANA COCINA
		vf.getVpc().getProductoTodo().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpc().setVisible(false);
				vf.getVpr().setVisible(true);
				vf.getVpr().repaint();

			}
		});

		vf.getVpc().getProductoBanio().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpc().setVisible(false);
				vf.getVpb().setVisible(true);
				vf.getVpb().repaint();

			}
		});

		vf.getVpc().getProductoCocina().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpc().setVisible(false);
				vf.getVpc().setVisible(true);
				vf.getVpc().repaint();

			}
		});

		vf.getVpc().getProductoJuguete().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpc().setVisible(false);
				vf.getVpj().setVisible(true);
				vf.getVpj().repaint();

			}
		});

		vf.getVpc().getProductoRopa().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpc().setVisible(false);
				vf.getVpro().setVisible(true);
				vf.getVpro().repaint();

			}
		});

		vf.getVpc().getProductoElectro().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpc().setVisible(false);
				vf.getVpe().setVisible(true);
				vf.getVpe().repaint();

			}
		});

		vf.getVpc().getProductoPapeleria().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpc().setVisible(false);
				vf.getVpp().setVisible(true);
				vf.getVpp().repaint();

			}
		});

		vf.getVpc().getProductoRecomend().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpc().setVisible(false);
				vf.getVpre().setVisible(true);
				vf.getVpre().repaint();

			}
		});

		// PRODUCTO JUGUETE
		vf.getVpj().getProductoTodo().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpj().setVisible(false);
				vf.getVpr().setVisible(true);
				vf.getVpr().repaint();

			}
		});

		vf.getVpj().getProductoBanio().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpj().setVisible(false);
				vf.getVpb().setVisible(true);
				vf.getVpb().repaint();

			}
		});

		vf.getVpj().getProductoCocina().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpj().setVisible(false);
				vf.getVpc().setVisible(true);
				vf.getVpc().repaint();

			}
		});

		vf.getVpj().getProductoJuguete().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpj().setVisible(false);
				vf.getVpj().setVisible(true);
				vf.getVpj().repaint();

			}
		});

		vf.getVpj().getProductoRopa().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpj().setVisible(false);
				vf.getVpro().setVisible(true);
				vf.getVpro().repaint();

			}
		});

		vf.getVpj().getProductoElectro().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpj().setVisible(false);
				vf.getVpe().setVisible(true);
				vf.getVpe().repaint();

			}
		});

		vf.getVpj().getProductoPapeleria().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpj().setVisible(false);
				vf.getVpp().setVisible(true);
				vf.getVpp().repaint();

			}
		});

		vf.getVpj().getProductoRecomend().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpj().setVisible(false);
				vf.getVpre().setVisible(true);
				vf.getVpre().repaint();

			}
		});

		// VENTANA ROPA
		vf.getVpro().getProductoTodo().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpro().setVisible(false);
				vf.getVpr().setVisible(true);
				vf.getVpr().repaint();

			}
		});

		vf.getVpro().getProductoBanio().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpro().setVisible(false);
				vf.getVpb().setVisible(true);
				vf.getVpb().repaint();

			}
		});

		vf.getVpro().getProductoCocina().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpro().setVisible(false);
				vf.getVpc().setVisible(true);
				vf.getVpc().repaint();

			}
		});

		vf.getVpro().getProductoJuguete().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpro().setVisible(false);
				vf.getVpj().setVisible(true);
				vf.getVpj().repaint();

			}
		});

		vf.getVpro().getProductoRopa().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpro().setVisible(false);
				vf.getVpro().setVisible(true);
				vf.getVpro().repaint();

			}
		});

		vf.getVpro().getProductoElectro().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpro().setVisible(false);
				vf.getVpe().setVisible(true);
				vf.getVpe().repaint();

			}
		});

		vf.getVpro().getProductoPapeleria().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpro().setVisible(false);
				vf.getVpp().setVisible(true);
				vf.getVpp().repaint();

			}
		});

		vf.getVpro().getProductoRecomend().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpro().setVisible(false);
				vf.getVpre().setVisible(true);
				vf.getVpre().repaint();

			}
		});
		// VENTANA ELECTRO
		vf.getVpe().getProductoTodo().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpe().setVisible(false);
				vf.getVpr().setVisible(true);
				vf.getVpr().repaint();

			}
		});

		vf.getVpe().getProductoBanio().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpe().setVisible(false);
				vf.getVpb().setVisible(true);
				vf.getVpb().repaint();

			}
		});

		vf.getVpe().getProductoCocina().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpe().setVisible(false);
				vf.getVpc().setVisible(true);
				vf.getVpc().repaint();

			}
		});

		vf.getVpe().getProductoJuguete().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpe().setVisible(false);
				vf.getVpj().setVisible(true);
				vf.getVpj().repaint();

			}
		});

		vf.getVpe().getProductoRopa().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpe().setVisible(false);
				vf.getVpro().setVisible(true);
				vf.getVpro().repaint();

			}
		});

		vf.getVpe().getProductoElectro().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpe().setVisible(false);
				vf.getVpe().setVisible(true);
				vf.getVpe().repaint();

			}
		});

		vf.getVpe().getProductoPapeleria().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpe().setVisible(false);
				vf.getVpp().setVisible(true);
				vf.getVpp().repaint();

			}
		});

		vf.getVpe().getProductoRecomend().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpe().setVisible(false);
				vf.getVpre().setVisible(true);
				vf.getVpre().repaint();

			}
		});
		// VENTANA PAPELERIA
		vf.getVpp().getProductoTodo().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpp().setVisible(false);
				vf.getVpr().setVisible(true);
				vf.getVpr().repaint();

			}
		});

		vf.getVpp().getProductoBanio().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpp().setVisible(false);
				vf.getVpb().setVisible(true);
				vf.getVpb().repaint();

			}
		});

		vf.getVpp().getProductoCocina().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpp().setVisible(false);
				vf.getVpc().setVisible(true);
				vf.getVpc().repaint();

			}
		});

		vf.getVpp().getProductoJuguete().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpp().setVisible(false);
				vf.getVpj().setVisible(true);
				vf.getVpj().repaint();

			}
		});

		vf.getVpp().getProductoRopa().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpp().setVisible(false);
				vf.getVpro().setVisible(true);
				vf.getVpro().repaint();

			}
		});

		vf.getVpp().getProductoElectro().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpp().setVisible(false);
				vf.getVpe().setVisible(true);
				vf.getVpe().repaint();

			}
		});

		vf.getVpp().getProductoPapeleria().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpp().setVisible(false);
				vf.getVpp().setVisible(true);
				vf.getVpp().repaint();

			}
		});

		vf.getVpp().getProductoRecomend().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpp().setVisible(false);
				vf.getVpre().setVisible(true);
				vf.getVpre().repaint();

			}
		});

		// VENTANA RECOMEND
		vf.getVpre().getProductoTodo().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpre().setVisible(false);
				vf.getVpr().setVisible(true);
				vf.getVpr().repaint();

			}
		});

		vf.getVpre().getProductoBanio().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpre().setVisible(false);
				vf.getVpb().setVisible(true);
				vf.getVpb().repaint();

			}
		});

		vf.getVpre().getProductoCocina().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpre().setVisible(false);
				vf.getVpc().setVisible(true);
				vf.getVpc().repaint();

			}
		});

		vf.getVpre().getProductoJuguete().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpre().setVisible(false);
				vf.getVpj().setVisible(true);
				vf.getVpj().repaint();

			}
		});

		vf.getVpre().getProductoRopa().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpre().setVisible(false);
				vf.getVpro().setVisible(true);
				vf.getVpro().repaint();

			}
		});

		vf.getVpre().getProductoElectro().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpre().setVisible(false);
				vf.getVpe().setVisible(true);
				vf.getVpe().repaint();

			}
		});

		vf.getVpre().getProductoPapeleria().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpre().setVisible(false);
				vf.getVpp().setVisible(true);
				vf.getVpp().repaint();

			}
		});

		vf.getVpre().getProductoRecomend().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				vf.getVpre().setVisible(false);
				vf.getVpre().setVisible(true);
				vf.getVpre().repaint();

			}
		});

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		switch (e.getActionCommand()) {

		case "checkEspañol": {
			if (vf.getVp().getPp().getCheckEspañol().isSelected()) {
				try {
					prop.load(new FileInputStream(new File("src/archivos/textosespañol.properties")));
					vf.getVp().getPp().getSeleccionarIdioma()
							.setText(prop.getProperty("tiendastemucliente.selectoridioma.texto"));
					vf.getVp().getPp().getCheckEspañol()
							.setText(prop.getProperty("tiendastemucliente.selectoridioma.español"));
					vf.getVp().getPp().getCheckIngles()
							.setText(prop.getProperty("tiendastemucliente.selectoridioma.ingles"));
					vf.getVp().getPp().getSaludo()
							.setText(prop.getProperty("tiendastemucliente.ventanaprincipal.saludo"));
					vf.getVp().getPp().getIngresar()
							.setText(prop.getProperty("tiendastemucliente.ventanaprincipal.ingresar"));
					vf.getVp().setTitle(prop.getProperty("tiendastemucliente.nombreventana.principal"));
					vf.getVp().getPp().revalidate();
					vf.getVp().getPp().repaint();

					vf.getVpr().getMenuCarrito().setText(prop.getProperty("tiendastemucliente.barramenu.carrito"));
					vf.getVpr().getMenuIdioma().setText(prop.getProperty("tiendastemucliente.barramenu.idioma"));
					vf.getVpr().getMenuSalir().setText(prop.getProperty("tiendastemucliente.barramenu.salida"));
					vf.getVpr().getMenuCategorias().setText(prop.getProperty("tiendastemucliente.barramenu.categoria"));
					vf.getVpr().getMenuDescuentos()
							.setText(prop.getProperty("tiendastemucliente.barramenu.descuentos"));
					vf.getVpr().getProductoTodos().setText(prop.getProperty("tiendastemucliente.barramenu.todo"));
					vf.getVpr().getProductoBanio().setText(prop.getProperty("tiendastemucliente.barramenu.baños"));
					vf.getVpr().getProductoCocina().setText(prop.getProperty("tiendastemucliente.barramenu.cocina"));
					vf.getVpr().getProductoJuguete().setText(prop.getProperty("tiendastemucliente.barramenu.juguetes"));
					vf.getVpr().getProductoRopa().setText(prop.getProperty("tiendastemucliente.barramenu.ropa"));
					vf.getVpr().getProductoElectro().setText(prop.getProperty("tiendastemucliente.barramenu.electro"));
					vf.getVpr().getProductoPapeleria()
							.setText(prop.getProperty("tiendastemucliente.barramenu.papeleria"));
					vf.getVpr().getProductoRecomend()
							.setText(prop.getProperty("tiendastemucliente.barramenu.recomend"));
					vf.getVpr().revalidate();
					vf.getVpr().repaint();

				} catch (FileNotFoundException e1) {
					e1.printStackTrace();
				} catch (IOException e1) {
					e1.printStackTrace();
				}

				vf.getVp().getPp().getCheckIngles().setSelected(false);
			}

			break;
		}

		case "checkIngles": {
			if (vf.getVp().getPp().getCheckIngles().isSelected()) {
				try {
					prop.load(new FileInputStream(new File("src/archivos/textosingles.properties")));
					vf.getVp().getPp().getSeleccionarIdioma()
							.setText(prop.getProperty("tiendastemucliente.selectoridioma.texto"));
					vf.getVp().getPp().getCheckEspañol()
							.setText(prop.getProperty("tiendastemucliente.selectoridioma.español"));
					vf.getVp().getPp().getCheckIngles()
							.setText(prop.getProperty("tiendastemucliente.selectoridioma.ingles"));
					vf.getVp().getPp().getSaludo()
							.setText(prop.getProperty("tiendastemucliente.ventanaprincipal.saludo"));
					vf.getVp().getPp().getIngresar()
							.setText(prop.getProperty("tiendastemucliente.ventanaprincipal.ingresar"));
					vf.getVp().setTitle(prop.getProperty("tiendastemucliente.nombreventana.principal"));
					vf.getVp().getPp().revalidate();
					vf.getVp().getPp().repaint();

					vf.getVpr().getMenuCarrito().setText(prop.getProperty("tiendastemucliente.barramenu.carrito"));
					vf.getVpr().getMenuIdioma().setText(prop.getProperty("tiendastemucliente.barramenu.idioma"));
					vf.getVpr().getMenuSalir().setText(prop.getProperty("tiendastemucliente.barramenu.salida"));
					vf.getVpr().getMenuCategorias().setText(prop.getProperty("tiendastemucliente.barramenu.categoria"));
					vf.getVpr().getMenuDescuentos()
							.setText(prop.getProperty("tiendastemucliente.barramenu.descuentos"));
					vf.getVpr().getProductoTodos().setText(prop.getProperty("tiendastemucliente.barramenu.todo"));
					vf.getVpr().getProductoBanio().setText(prop.getProperty("tiendastemucliente.barramenu.baños"));
					vf.getVpr().getProductoCocina().setText(prop.getProperty("tiendastemucliente.barramenu.cocina"));
					vf.getVpr().getProductoJuguete().setText(prop.getProperty("tiendastemucliente.barramenu.juguetes"));
					vf.getVpr().getProductoRopa().setText(prop.getProperty("tiendastemucliente.barramenu.ropa"));
					vf.getVpr().getProductoElectro().setText(prop.getProperty("tiendastemucliente.barramenu.electro"));
					vf.getVpr().getProductoPapeleria()
							.setText(prop.getProperty("tiendastemucliente.barramenu.papeleria"));
					vf.getVpr().getProductoRecomend()
							.setText(prop.getProperty("tiendastemucliente.barramenu.recomend"));
					vf.getVpr().setTitle(prop.getProperty("tiendastemucliente.nombreventana.todos"));
					vf.getVpr().revalidate();
					vf.getVpr().repaint();

				} catch (FileNotFoundException e1) {
					e1.printStackTrace();
				} catch (IOException e1) {
					e1.printStackTrace();
				}

				vf.getVp().getPp().getCheckEspañol().setSelected(false);
			}

			break;
		}

		case "btnIngresar": {
			vf.getVpr().setVisible(true);
			vf.getVp().setVisible(false);

			break;

		}

		case "checkEspañol2": {

			if (vf.getVsi().getPsi().getCheckEspañol().isSelected()) {
				try {
					prop.load(new FileInputStream(new File("src/archivos/textosespañol.properties")));
					vf.getVpr().getMenuCarrito().setText(prop.getProperty("tiendastemucliente.barramenu.carrito"));
					vf.getVpr().getMenuIdioma().setText(prop.getProperty("tiendastemucliente.barramenu.idioma"));
					vf.getVpr().getMenuSalir().setText(prop.getProperty("tiendastemucliente.barramenu.salida"));
					vf.getVpr().getMenuCategorias().setText(prop.getProperty("tiendastemucliente.barramenu.categoria"));
					vf.getVpr().getMenuDescuentos()
							.setText(prop.getProperty("tiendastemucliente.barramenu.descuentos"));
					vf.getVpr().getProductoTodos().setText(prop.getProperty("tiendastemucliente.barramenu.todo"));
					vf.getVpr().getProductoBanio().setText(prop.getProperty("tiendastemucliente.barramenu.baños"));
					vf.getVpr().getProductoCocina().setText(prop.getProperty("tiendastemucliente.barramenu.cocina"));
					vf.getVpr().getProductoJuguete().setText(prop.getProperty("tiendastemucliente.barramenu.juguetes"));
					vf.getVpr().getProductoRopa().setText(prop.getProperty("tiendastemucliente.barramenu.ropa"));
					vf.getVpr().getProductoElectro().setText(prop.getProperty("tiendastemucliente.barramenu.electro"));
					vf.getVpr().getProductoPapeleria()
							.setText(prop.getProperty("tiendastemucliente.barramenu.papeleria"));
					vf.getVpr().getProductoRecomend()
							.setText(prop.getProperty("tiendastemucliente.barramenu.recomend"));
					vf.getVpr().setTitle(prop.getProperty("tiendastemucliente.nombreventana.todos"));
					vf.getVpr().revalidate();
					vf.getVpr().repaint();

					vf.getVpb().getMenuCarrito().setText(prop.getProperty("tiendastemucliente.barramenu.carrito"));
					vf.getVpb().getMenuIdioma().setText(prop.getProperty("tiendastemucliente.barramenu.idioma"));
					vf.getVpb().getMenuSalir().setText(prop.getProperty("tiendastemucliente.barramenu.salida"));
					vf.getVpb().getMenuCategorias().setText(prop.getProperty("tiendastemucliente.barramenu.categoria"));
					vf.getVpb().getMenuDescuentos()
							.setText(prop.getProperty("tiendastemucliente.barramenu.descuentos"));
					vf.getVpb().getProductoTodo().setText(prop.getProperty("tiendastemucliente.barramenu.todo"));
					vf.getVpb().getProductoBanio().setText(prop.getProperty("tiendastemucliente.barramenu.baños"));
					vf.getVpb().getProductoCocina().setText(prop.getProperty("tiendastemucliente.barramenu.cocina"));
					vf.getVpb().getProductoJuguete().setText(prop.getProperty("tiendastemucliente.barramenu.juguetes"));
					vf.getVpb().getProductoRopa().setText(prop.getProperty("tiendastemucliente.barramenu.ropa"));
					vf.getVpb().getProductoElectro().setText(prop.getProperty("tiendastemucliente.barramenu.electro"));
					vf.getVpb().getProductoPapeleria()
							.setText(prop.getProperty("tiendastemucliente.barramenu.papeleria"));
					vf.getVpb().getProductoRecomend()
							.setText(prop.getProperty("tiendastemucliente.barramenu.recomend"));
					vf.getVpb().setTitle(prop.getProperty("tiendastemucliente.nombreventana.baño"));
					vf.getVpb().revalidate();
					vf.getVpb().repaint();

					vf.getVpc().getMenuCarrito().setText(prop.getProperty("tiendastemucliente.barramenu.carrito"));
					vf.getVpc().getMenuIdioma().setText(prop.getProperty("tiendastemucliente.barramenu.idioma"));
					vf.getVpc().getMenuSalir().setText(prop.getProperty("tiendastemucliente.barramenu.salida"));
					vf.getVpc().getMenuCategorias().setText(prop.getProperty("tiendastemucliente.barramenu.categoria"));
					vf.getVpc().getMenuDescuentos()
							.setText(prop.getProperty("tiendastemucliente.barramenu.descuentos"));
					vf.getVpc().getProductoTodo().setText(prop.getProperty("tiendastemucliente.barramenu.todo"));
					vf.getVpc().getProductoBanio().setText(prop.getProperty("tiendastemucliente.barramenu.baños"));
					vf.getVpc().getProductoCocina().setText(prop.getProperty("tiendastemucliente.barramenu.cocina"));
					vf.getVpc().getProductoJuguete().setText(prop.getProperty("tiendastemucliente.barramenu.juguetes"));
					vf.getVpc().getProductoRopa().setText(prop.getProperty("tiendastemucliente.barramenu.ropa"));
					vf.getVpc().getProductoElectro().setText(prop.getProperty("tiendastemucliente.barramenu.electro"));
					vf.getVpc().getProductoPapeleria()
							.setText(prop.getProperty("tiendastemucliente.barramenu.papeleria"));
					vf.getVpc().getProductoRecomend()
							.setText(prop.getProperty("tiendastemucliente.barramenu.recomend"));
					vf.getVpc().setTitle(prop.getProperty("tiendastemucliente.nombreventana.cocina"));
					vf.getVpc().revalidate();
					vf.getVpc().repaint();

					vf.getVpj().getMenuCarrito().setText(prop.getProperty("tiendastemucliente.barramenu.carrito"));
					vf.getVpj().getMenuIdioma().setText(prop.getProperty("tiendastemucliente.barramenu.idioma"));
					vf.getVpj().getMenuSalir().setText(prop.getProperty("tiendastemucliente.barramenu.salida"));
					vf.getVpj().getMenuCategorias().setText(prop.getProperty("tiendastemucliente.barramenu.categoria"));
					vf.getVpj().getMenuDescuentos()
							.setText(prop.getProperty("tiendastemucliente.barramenu.descuentos"));
					vf.getVpj().getProductoTodo().setText(prop.getProperty("tiendastemucliente.barramenu.todo"));
					vf.getVpj().getProductoBanio().setText(prop.getProperty("tiendastemucliente.barramenu.baños"));
					vf.getVpj().getProductoCocina().setText(prop.getProperty("tiendastemucliente.barramenu.cocina"));
					vf.getVpj().getProductoJuguete().setText(prop.getProperty("tiendastemucliente.barramenu.juguetes"));
					vf.getVpj().getProductoRopa().setText(prop.getProperty("tiendastemucliente.barramenu.ropa"));
					vf.getVpj().getProductoElectro().setText(prop.getProperty("tiendastemucliente.barramenu.electro"));
					vf.getVpj().getProductoPapeleria()
							.setText(prop.getProperty("tiendastemucliente.barramenu.papeleria"));
					vf.getVpj().getProductoRecomend()
							.setText(prop.getProperty("tiendastemucliente.barramenu.recomend"));
					vf.getVpj().setTitle(prop.getProperty("tiendastemucliente.nombreventana.juguetes"));
					vf.getVpj().revalidate();
					vf.getVpj().repaint();

					vf.getVpro().getMenuCarrito().setText(prop.getProperty("tiendastemucliente.barramenu.carrito"));
					vf.getVpro().getMenuIdioma().setText(prop.getProperty("tiendastemucliente.barramenu.idioma"));
					vf.getVpro().getMenuSalir().setText(prop.getProperty("tiendastemucliente.barramenu.salida"));
					vf.getVpro().getMenuCategorias()
							.setText(prop.getProperty("tiendastemucliente.barramenu.categoria"));
					vf.getVpro().getMenuDescuentos()
							.setText(prop.getProperty("tiendastemucliente.barramenu.descuentos"));
					vf.getVpro().getProductoTodo().setText(prop.getProperty("tiendastemucliente.barramenu.todo"));
					vf.getVpro().getProductoBanio().setText(prop.getProperty("tiendastemucliente.barramenu.baños"));
					vf.getVpro().getProductoCocina().setText(prop.getProperty("tiendastemucliente.barramenu.cocina"));
					vf.getVpro().getProductoJuguete()
							.setText(prop.getProperty("tiendastemucliente.barramenu.juguetes"));
					vf.getVpro().getProductoRopa().setText(prop.getProperty("tiendastemucliente.barramenu.ropa"));
					vf.getVpro().getProductoElectro().setText(prop.getProperty("tiendastemucliente.barramenu.electro"));
					vf.getVpro().getProductoPapeleria()
							.setText(prop.getProperty("tiendastemucliente.barramenu.papeleria"));
					vf.getVpro().getProductoRecomend()
							.setText(prop.getProperty("tiendastemucliente.barramenu.recomend"));
					vf.getVpro().setTitle(prop.getProperty("tiendastemucliente.nombreventana.ropa"));
					vf.getVpro().revalidate();
					vf.getVpro().repaint();

					vf.getVpe().getMenuCarrito().setText(prop.getProperty("tiendastemucliente.barramenu.carrito"));
					vf.getVpe().getMenuIdioma().setText(prop.getProperty("tiendastemucliente.barramenu.idioma"));
					vf.getVpe().getMenuSalir().setText(prop.getProperty("tiendastemucliente.barramenu.salida"));
					vf.getVpe().getMenuCategorias().setText(prop.getProperty("tiendastemucliente.barramenu.categoria"));
					vf.getVpe().getMenuDescuentos()
							.setText(prop.getProperty("tiendastemucliente.barramenu.descuentos"));
					vf.getVpe().getProductoTodo().setText(prop.getProperty("tiendastemucliente.barramenu.todo"));
					vf.getVpe().getProductoBanio().setText(prop.getProperty("tiendastemucliente.barramenu.baños"));
					vf.getVpe().getProductoCocina().setText(prop.getProperty("tiendastemucliente.barramenu.cocina"));
					vf.getVpe().getProductoJuguete().setText(prop.getProperty("tiendastemucliente.barramenu.juguetes"));
					vf.getVpe().getProductoRopa().setText(prop.getProperty("tiendastemucliente.barramenu.ropa"));
					vf.getVpe().getProductoElectro().setText(prop.getProperty("tiendastemucliente.barramenu.electro"));
					vf.getVpe().getProductoPapeleria()
							.setText(prop.getProperty("tiendastemucliente.barramenu.papeleria"));
					vf.getVpe().getProductoRecomend()
							.setText(prop.getProperty("tiendastemucliente.barramenu.recomend"));
					vf.getVpe().setTitle(prop.getProperty("tiendastemucliente.nombreventana.electro"));
					vf.getVpe().revalidate();
					vf.getVpe().repaint();

					vf.getVpp().getMenuCarrito().setText(prop.getProperty("tiendastemucliente.barramenu.carrito"));
					vf.getVpp().getMenuIdioma().setText(prop.getProperty("tiendastemucliente.barramenu.idioma"));
					vf.getVpp().getMenuSalir().setText(prop.getProperty("tiendastemucliente.barramenu.salida"));
					vf.getVpp().getMenuCategorias().setText(prop.getProperty("tiendastemucliente.barramenu.categoria"));
					vf.getVpp().getMenuDescuentos()
							.setText(prop.getProperty("tiendastemucliente.barramenu.descuentos"));
					vf.getVpp().getProductoTodo().setText(prop.getProperty("tiendastemucliente.barramenu.todo"));
					vf.getVpp().getProductoBanio().setText(prop.getProperty("tiendastemucliente.barramenu.baños"));
					vf.getVpp().getProductoCocina().setText(prop.getProperty("tiendastemucliente.barramenu.cocina"));
					vf.getVpp().getProductoJuguete().setText(prop.getProperty("tiendastemucliente.barramenu.juguetes"));
					vf.getVpp().getProductoRopa().setText(prop.getProperty("tiendastemucliente.barramenu.ropa"));
					vf.getVpp().getProductoElectro().setText(prop.getProperty("tiendastemucliente.barramenu.electro"));
					vf.getVpp().getProductoPapeleria()
							.setText(prop.getProperty("tiendastemucliente.barramenu.papeleria"));
					vf.getVpp().getProductoRecomend()
							.setText(prop.getProperty("tiendastemucliente.barramenu.recomend"));
					vf.getVpp().setTitle(prop.getProperty("tiendastemucliente.nombreventana.papeleria"));
					vf.getVpp().revalidate();
					vf.getVpp().repaint();

					vf.getVpre().getMenuCarrito().setText(prop.getProperty("tiendastemucliente.barramenu.carrito"));
					vf.getVpre().getMenuIdioma().setText(prop.getProperty("tiendastemucliente.barramenu.idioma"));
					vf.getVpre().getMenuSalir().setText(prop.getProperty("tiendastemucliente.barramenu.salida"));
					vf.getVpre().getMenuCategorias()
							.setText(prop.getProperty("tiendastemucliente.barramenu.categoria"));
					vf.getVpre().getMenuDescuentos()
							.setText(prop.getProperty("tiendastemucliente.barramenu.descuentos"));
					vf.getVpre().getProductoTodo().setText(prop.getProperty("tiendastemucliente.barramenu.todo"));
					vf.getVpre().getProductoBanio().setText(prop.getProperty("tiendastemucliente.barramenu.baños"));
					vf.getVpre().getProductoCocina().setText(prop.getProperty("tiendastemucliente.barramenu.cocina"));
					vf.getVpre().getProductoJuguete()
							.setText(prop.getProperty("tiendastemucliente.barramenu.juguetes"));
					vf.getVpre().getProductoRopa().setText(prop.getProperty("tiendastemucliente.barramenu.ropa"));
					vf.getVpre().getProductoElectro().setText(prop.getProperty("tiendastemucliente.barramenu.electro"));
					vf.getVpre().getProductoPapeleria()
							.setText(prop.getProperty("tiendastemucliente.barramenu.papeleria"));
					vf.getVpre().getProductoRecomend()
							.setText(prop.getProperty("tiendastemucliente.barramenu.recomend"));
					vf.getVpre().setTitle(prop.getProperty("tiendastemucliente.nombreventana.recomend"));
					vf.getVpre().revalidate();
					vf.getVpre().repaint();

					vf.getVsi().getPsi().getIdioma()
							.setText(prop.getProperty("tiendastemucliente.selectoridioma.texto"));
					vf.getVsi().getPsi().getCheckEspañol()
							.setText(prop.getProperty("tiendastemucliente.selectoridioma.español"));
					vf.getVsi().getPsi().getCheckIngles()
							.setText(prop.getProperty("tiendastemucliente.selectoridioma.ingles"));
					vf.getVsi().setTitle(prop.getProperty("tiendastemucliente.nombreventana.idioma"));
					vf.getVsi().revalidate();
					vf.getVsi().repaint();
				} catch (FileNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				vf.getVsi().getPsi().getCheckIngles().setSelected(false);
			}

			break;
		}

		case "checkIngles2": {

			if (vf.getVsi().getPsi().getCheckIngles().isSelected()) {

				try {
					prop.load(new FileInputStream(new File("src/archivos/textosingles.properties")));
					vf.getVpr().getMenuCarrito().setText(prop.getProperty("tiendastemucliente.barramenu.carrito"));
					vf.getVpr().getMenuIdioma().setText(prop.getProperty("tiendastemucliente.barramenu.idioma"));
					vf.getVpr().getMenuSalir().setText(prop.getProperty("tiendastemucliente.barramenu.salida"));
					vf.getVpr().getMenuCategorias().setText(prop.getProperty("tiendastemucliente.barramenu.categoria"));
					vf.getVpr().getMenuDescuentos()
							.setText(prop.getProperty("tiendastemucliente.barramenu.descuentos"));
					vf.getVpr().getProductoTodos().setText(prop.getProperty("tiendastemucliente.barramenu.todo"));
					vf.getVpr().getProductoBanio().setText(prop.getProperty("tiendastemucliente.barramenu.baños"));
					vf.getVpr().getProductoCocina().setText(prop.getProperty("tiendastemucliente.barramenu.cocina"));
					vf.getVpr().getProductoJuguete().setText(prop.getProperty("tiendastemucliente.barramenu.juguetes"));
					vf.getVpr().getProductoRopa().setText(prop.getProperty("tiendastemucliente.barramenu.ropa"));
					vf.getVpr().getProductoElectro().setText(prop.getProperty("tiendastemucliente.barramenu.electro"));
					vf.getVpr().getProductoPapeleria()
							.setText(prop.getProperty("tiendastemucliente.barramenu.papeleria"));
					vf.getVpr().getProductoRecomend()
							.setText(prop.getProperty("tiendastemucliente.barramenu.recomend"));
					vf.getVpr().setTitle(prop.getProperty("tiendastemucliente.nombreventana.todos"));
					vf.getVpr().revalidate();
					vf.getVpr().repaint();

					vf.getVpb().getMenuCarrito().setText(prop.getProperty("tiendastemucliente.barramenu.carrito"));
					vf.getVpb().getMenuIdioma().setText(prop.getProperty("tiendastemucliente.barramenu.idioma"));
					vf.getVpb().getMenuSalir().setText(prop.getProperty("tiendastemucliente.barramenu.salida"));
					vf.getVpb().getMenuCategorias().setText(prop.getProperty("tiendastemucliente.barramenu.categoria"));
					vf.getVpb().getMenuDescuentos()
							.setText(prop.getProperty("tiendastemucliente.barramenu.descuentos"));
					vf.getVpb().getProductoTodo().setText(prop.getProperty("tiendastemucliente.barramenu.todo"));
					vf.getVpb().getProductoBanio().setText(prop.getProperty("tiendastemucliente.barramenu.baños"));
					vf.getVpb().getProductoCocina().setText(prop.getProperty("tiendastemucliente.barramenu.cocina"));
					vf.getVpb().getProductoJuguete().setText(prop.getProperty("tiendastemucliente.barramenu.juguetes"));
					vf.getVpb().getProductoRopa().setText(prop.getProperty("tiendastemucliente.barramenu.ropa"));
					vf.getVpb().getProductoElectro().setText(prop.getProperty("tiendastemucliente.barramenu.electro"));
					vf.getVpb().getProductoPapeleria()
							.setText(prop.getProperty("tiendastemucliente.barramenu.papeleria"));
					vf.getVpb().getProductoRecomend()
							.setText(prop.getProperty("tiendastemucliente.barramenu.recomend"));
					vf.getVpb().setTitle(prop.getProperty("tiendastemucliente.nombreventana.baño"));
					vf.getVpb().revalidate();
					vf.getVpb().repaint();

					vf.getVpc().getMenuCarrito().setText(prop.getProperty("tiendastemucliente.barramenu.carrito"));
					vf.getVpc().getMenuIdioma().setText(prop.getProperty("tiendastemucliente.barramenu.idioma"));
					vf.getVpc().getMenuSalir().setText(prop.getProperty("tiendastemucliente.barramenu.salida"));
					vf.getVpc().getMenuCategorias().setText(prop.getProperty("tiendastemucliente.barramenu.categoria"));
					vf.getVpc().getMenuDescuentos()
							.setText(prop.getProperty("tiendastemucliente.barramenu.descuentos"));
					vf.getVpc().getProductoTodo().setText(prop.getProperty("tiendastemucliente.barramenu.todo"));
					vf.getVpc().getProductoBanio().setText(prop.getProperty("tiendastemucliente.barramenu.baños"));
					vf.getVpc().getProductoCocina().setText(prop.getProperty("tiendastemucliente.barramenu.cocina"));
					vf.getVpc().getProductoJuguete().setText(prop.getProperty("tiendastemucliente.barramenu.juguetes"));
					vf.getVpc().getProductoRopa().setText(prop.getProperty("tiendastemucliente.barramenu.ropa"));
					vf.getVpc().getProductoElectro().setText(prop.getProperty("tiendastemucliente.barramenu.electro"));
					vf.getVpc().getProductoPapeleria()
							.setText(prop.getProperty("tiendastemucliente.barramenu.papeleria"));
					vf.getVpc().getProductoRecomend()
							.setText(prop.getProperty("tiendastemucliente.barramenu.recomend"));
					vf.getVpc().setTitle(prop.getProperty("tiendastemucliente.nombreventana.cocina"));
					vf.getVpc().revalidate();
					vf.getVpc().repaint();

					vf.getVpj().getMenuCarrito().setText(prop.getProperty("tiendastemucliente.barramenu.carrito"));
					vf.getVpj().getMenuIdioma().setText(prop.getProperty("tiendastemucliente.barramenu.idioma"));
					vf.getVpj().getMenuSalir().setText(prop.getProperty("tiendastemucliente.barramenu.salida"));
					vf.getVpj().getMenuCategorias().setText(prop.getProperty("tiendastemucliente.barramenu.categoria"));
					vf.getVpj().getMenuDescuentos()
							.setText(prop.getProperty("tiendastemucliente.barramenu.descuentos"));
					vf.getVpj().getProductoTodo().setText(prop.getProperty("tiendastemucliente.barramenu.todo"));
					vf.getVpj().getProductoBanio().setText(prop.getProperty("tiendastemucliente.barramenu.baños"));
					vf.getVpj().getProductoCocina().setText(prop.getProperty("tiendastemucliente.barramenu.cocina"));
					vf.getVpj().getProductoJuguete().setText(prop.getProperty("tiendastemucliente.barramenu.juguetes"));
					vf.getVpj().getProductoRopa().setText(prop.getProperty("tiendastemucliente.barramenu.ropa"));
					vf.getVpj().getProductoElectro().setText(prop.getProperty("tiendastemucliente.barramenu.electro"));
					vf.getVpj().getProductoPapeleria()
							.setText(prop.getProperty("tiendastemucliente.barramenu.papeleria"));
					vf.getVpj().getProductoRecomend()
							.setText(prop.getProperty("tiendastemucliente.barramenu.recomend"));
					vf.getVpj().setTitle(prop.getProperty("tiendastemucliente.nombreventana.juguetes"));
					vf.getVpj().revalidate();
					vf.getVpj().repaint();

					vf.getVpro().getMenuCarrito().setText(prop.getProperty("tiendastemucliente.barramenu.carrito"));
					vf.getVpro().getMenuIdioma().setText(prop.getProperty("tiendastemucliente.barramenu.idioma"));
					vf.getVpro().getMenuSalir().setText(prop.getProperty("tiendastemucliente.barramenu.salida"));
					vf.getVpro().getMenuCategorias()
							.setText(prop.getProperty("tiendastemucliente.barramenu.categoria"));
					vf.getVpro().getMenuDescuentos()
							.setText(prop.getProperty("tiendastemucliente.barramenu.descuentos"));
					vf.getVpro().getProductoTodo().setText(prop.getProperty("tiendastemucliente.barramenu.todo"));
					vf.getVpro().getProductoBanio().setText(prop.getProperty("tiendastemucliente.barramenu.baños"));
					vf.getVpro().getProductoCocina().setText(prop.getProperty("tiendastemucliente.barramenu.cocina"));
					vf.getVpro().getProductoJuguete()
							.setText(prop.getProperty("tiendastemucliente.barramenu.juguetes"));
					vf.getVpro().getProductoRopa().setText(prop.getProperty("tiendastemucliente.barramenu.ropa"));
					vf.getVpro().getProductoElectro().setText(prop.getProperty("tiendastemucliente.barramenu.electro"));
					vf.getVpro().getProductoPapeleria()
							.setText(prop.getProperty("tiendastemucliente.barramenu.papeleria"));
					vf.getVpro().getProductoRecomend()
							.setText(prop.getProperty("tiendastemucliente.barramenu.recomend"));
					vf.getVpro().setTitle(prop.getProperty("tiendastemucliente.nombreventana.ropa"));
					vf.getVpro().revalidate();
					vf.getVpro().repaint();

					vf.getVpe().getMenuCarrito().setText(prop.getProperty("tiendastemucliente.barramenu.carrito"));
					vf.getVpe().getMenuIdioma().setText(prop.getProperty("tiendastemucliente.barramenu.idioma"));
					vf.getVpe().getMenuSalir().setText(prop.getProperty("tiendastemucliente.barramenu.salida"));
					vf.getVpe().getMenuCategorias().setText(prop.getProperty("tiendastemucliente.barramenu.categoria"));
					vf.getVpe().getMenuDescuentos()
							.setText(prop.getProperty("tiendastemucliente.barramenu.descuentos"));
					vf.getVpe().getProductoTodo().setText(prop.getProperty("tiendastemucliente.barramenu.todo"));
					vf.getVpe().getProductoBanio().setText(prop.getProperty("tiendastemucliente.barramenu.baños"));
					vf.getVpe().getProductoCocina().setText(prop.getProperty("tiendastemucliente.barramenu.cocina"));
					vf.getVpe().getProductoJuguete().setText(prop.getProperty("tiendastemucliente.barramenu.juguetes"));
					vf.getVpe().getProductoRopa().setText(prop.getProperty("tiendastemucliente.barramenu.ropa"));
					vf.getVpe().getProductoElectro().setText(prop.getProperty("tiendastemucliente.barramenu.electro"));
					vf.getVpe().getProductoPapeleria()
							.setText(prop.getProperty("tiendastemucliente.barramenu.papeleria"));
					vf.getVpe().getProductoRecomend()
							.setText(prop.getProperty("tiendastemucliente.barramenu.recomend"));
					vf.getVpe().setTitle(prop.getProperty("tiendastemucliente.nombreventana.electro"));
					vf.getVpe().revalidate();
					vf.getVpe().repaint();

					vf.getVpp().getMenuCarrito().setText(prop.getProperty("tiendastemucliente.barramenu.carrito"));
					vf.getVpp().getMenuIdioma().setText(prop.getProperty("tiendastemucliente.barramenu.idioma"));
					vf.getVpp().getMenuSalir().setText(prop.getProperty("tiendastemucliente.barramenu.salida"));
					vf.getVpp().getMenuCategorias().setText(prop.getProperty("tiendastemucliente.barramenu.categoria"));
					vf.getVpp().getMenuDescuentos()
							.setText(prop.getProperty("tiendastemucliente.barramenu.descuentos"));
					vf.getVpp().getProductoTodo().setText(prop.getProperty("tiendastemucliente.barramenu.todo"));
					vf.getVpp().getProductoBanio().setText(prop.getProperty("tiendastemucliente.barramenu.baños"));
					vf.getVpp().getProductoCocina().setText(prop.getProperty("tiendastemucliente.barramenu.cocina"));
					vf.getVpp().getProductoJuguete().setText(prop.getProperty("tiendastemucliente.barramenu.juguetes"));
					vf.getVpp().getProductoRopa().setText(prop.getProperty("tiendastemucliente.barramenu.ropa"));
					vf.getVpp().getProductoElectro().setText(prop.getProperty("tiendastemucliente.barramenu.electro"));
					vf.getVpp().getProductoPapeleria()
							.setText(prop.getProperty("tiendastemucliente.barramenu.papeleria"));
					vf.getVpp().getProductoRecomend()
							.setText(prop.getProperty("tiendastemucliente.barramenu.recomend"));
					vf.getVpp().setTitle(prop.getProperty("tiendastemucliente.nombreventana.papeleria"));
					vf.getVpp().revalidate();
					vf.getVpp().repaint();

					vf.getVpre().getMenuCarrito().setText(prop.getProperty("tiendastemucliente.barramenu.carrito"));
					vf.getVpre().getMenuIdioma().setText(prop.getProperty("tiendastemucliente.barramenu.idioma"));
					vf.getVpre().getMenuSalir().setText(prop.getProperty("tiendastemucliente.barramenu.salida"));
					vf.getVpre().getMenuCategorias()
							.setText(prop.getProperty("tiendastemucliente.barramenu.categoria"));
					vf.getVpre().getMenuDescuentos()
							.setText(prop.getProperty("tiendastemucliente.barramenu.descuentos"));
					vf.getVpre().getProductoTodo().setText(prop.getProperty("tiendastemucliente.barramenu.todo"));
					vf.getVpre().getProductoBanio().setText(prop.getProperty("tiendastemucliente.barramenu.baños"));
					vf.getVpre().getProductoCocina().setText(prop.getProperty("tiendastemucliente.barramenu.cocina"));
					vf.getVpre().getProductoJuguete()
							.setText(prop.getProperty("tiendastemucliente.barramenu.juguetes"));
					vf.getVpre().getProductoRopa().setText(prop.getProperty("tiendastemucliente.barramenu.ropa"));
					vf.getVpre().getProductoElectro().setText(prop.getProperty("tiendastemucliente.barramenu.electro"));
					vf.getVpre().getProductoPapeleria()
							.setText(prop.getProperty("tiendastemucliente.barramenu.papeleria"));
					vf.getVpre().getProductoRecomend()
							.setText(prop.getProperty("tiendastemucliente.barramenu.recomend"));
					vf.getVpre().setTitle(prop.getProperty("tiendastemucliente.nombreventana.recomend"));
					vf.getVpre().revalidate();
					vf.getVpre().repaint();

					vf.getVsi().getPsi().getIdioma()
							.setText(prop.getProperty("tiendastemucliente.selectoridioma.texto"));
					vf.getVsi().getPsi().getCheckEspañol()
							.setText(prop.getProperty("tiendastemucliente.selectoridioma.español"));
					vf.getVsi().getPsi().getCheckIngles()
							.setText(prop.getProperty("tiendastemucliente.selectoridioma.ingles"));
					vf.getVsi().setTitle(prop.getProperty("tiendastemucliente.nombreventana.idioma"));
					vf.getVsi().revalidate();
					vf.getVsi().repaint();
				} catch (FileNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				vf.getVsi().getPsi().getCheckEspañol().setSelected(false);
			}

			break;
		}

		}

	}

}
