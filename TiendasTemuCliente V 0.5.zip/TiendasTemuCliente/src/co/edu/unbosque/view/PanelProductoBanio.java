package co.edu.unbosque.view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Image;

import javax.swing.JLabel;
import javax.swing.JPanel;

public class PanelProductoBanio extends JPanel {

	private final int ANCHO_PANEL = 1200, ALTO_PANEL = 1500;
	private JLabel productoBanio, productoCocina, productoJuguete, productoRopa, productoElectro, productoPapeleria,
			productoRecomend;
	private Image imagenBanio;

	public PanelProductoBanio() {
		setSize(1250, 700);
		setBounds(0, 0, ANCHO_PANEL, ALTO_PANEL);
		setPreferredSize(new Dimension(1250, 10500));
		setBackground(Color.white);
	}

	public JLabel getProductoBanio() {
		return productoBanio;
	}

	public void setProductoBanio(JLabel productoBanio) {
		this.productoBanio = productoBanio;
	}

	public JLabel getProductoCocina() {
		return productoCocina;
	}

	public void setProductoCocina(JLabel productoCocina) {
		this.productoCocina = productoCocina;
	}

	public JLabel getProductoJuguete() {
		return productoJuguete;
	}

	public void setProductoJuguete(JLabel productoJuguete) {
		this.productoJuguete = productoJuguete;
	}

	public JLabel getProductoRopa() {
		return productoRopa;
	}

	public void setProductoRopa(JLabel productoRopa) {
		this.productoRopa = productoRopa;
	}

	public JLabel getProductoElectro() {
		return productoElectro;
	}

	public void setProductoElectro(JLabel productoElectro) {
		this.productoElectro = productoElectro;
	}

	public JLabel getProductoPapeleria() {
		return productoPapeleria;
	}

	public void setProductoPapeleria(JLabel productoPapeleria) {
		this.productoPapeleria = productoPapeleria;
	}

	public JLabel getProductoRecomend() {
		return productoRecomend;
	}

	public void setProductoRecomend(JLabel productoRecomend) {
		this.productoRecomend = productoRecomend;
	}

	public Image getImagenBanio() {
		return imagenBanio;
	}

	public void setImagenBanio(Image imagenBanio) {
		this.imagenBanio = imagenBanio;
	}

	public int getANCHO_PANEL() {
		return ANCHO_PANEL;
	}

	public int getALTO_PANEL() {
		return ALTO_PANEL;
	}

}
