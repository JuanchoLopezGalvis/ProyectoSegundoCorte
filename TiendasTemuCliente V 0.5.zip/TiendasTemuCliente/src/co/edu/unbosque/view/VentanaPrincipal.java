package co.edu.unbosque.view;

import java.awt.Color;

import javax.swing.JFrame;

public class VentanaPrincipal extends JFrame {

	private PanelPrincipal pp;

	public VentanaPrincipal() {

		setSize(550, 550);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setResizable(false);
		setTitle("Tiendas Temu clientes");
		setLayout(null);
		pp = new PanelPrincipal();

		add(pp);
	}

	public PanelPrincipal getPp() {
		return pp;
	}

	public void setPp(PanelPrincipal pp) {
		this.pp = pp;
	}

}
