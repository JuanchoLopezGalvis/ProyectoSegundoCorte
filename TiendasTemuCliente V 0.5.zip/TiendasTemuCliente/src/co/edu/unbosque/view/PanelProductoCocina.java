package co.edu.unbosque.view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Image;

import javax.swing.JLabel;
import javax.swing.JPanel;

public class PanelProductoCocina extends JPanel {

	private final int ANCHO_PANEL = 1200, ALTO_PANEL = 1500;
	private JLabel productoCocina;
	private Image imagenCocina;

	public PanelProductoCocina() {
		setSize(1250, 700);
		setBounds(0, 0, ANCHO_PANEL, ALTO_PANEL);
		setPreferredSize(new Dimension(1250, 10500));
		setBackground(Color.white);
		
	}
}
