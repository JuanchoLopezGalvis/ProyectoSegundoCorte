package co.edu.unbosque.view;

import java.awt.Color;

import javax.swing.*;

public class VentanaSeleccionarIdioma extends JFrame {

	private PanelSeleccionarIdioma psi;

	public VentanaSeleccionarIdioma() {

		psi = new PanelSeleccionarIdioma();

		setSize(250, 250);
		setLocationRelativeTo(null);
//		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setResizable(false);
		setTitle("Cambiar idioma");
		setLayout(null);

		add(psi);

	}

	public PanelSeleccionarIdioma getPsi() {
		return psi;
	}

	public void setPsi(PanelSeleccionarIdioma psi) {
		this.psi = psi;
	}

}
