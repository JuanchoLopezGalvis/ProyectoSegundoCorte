package co.edu.unbosque.view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class PanelProducto extends JPanel {

	private final int ANCHO_PANEL = 1200, ALTO_PANEL = 1500;
	private JLabel productoBanio, productoCocina, productoJuguete, productoRopa, productoElectro, productoPapeleria,
			productoRecomend;
	private Image imagenBanio, imagenCocina, imagenJuguete, imagenRopa, imagnenElectro, imagenPapeleria;

	public PanelProducto() {
		setSize(1250, 700);
		setBounds(0, 0, ANCHO_PANEL, ALTO_PANEL);
		setPreferredSize(new Dimension(1250, 10500));
		setBackground(Color.white);

//		productoBanio = new JLabel("PRODUCTOS PARA EL BAÑO");
//		productoBanio.setBounds(0, 0, 500, 50);
//		productoBanio.setFont(new Font("Arial", Font.BOLD, 25));

//		productoCocina = new JLabel("PRODUCTOS PARA LA COCINA");
//		productoCocina.setBounds(1200, 1200, 300, 25);
//		productoCocina.setFont(new Font("Arial", Font.BOLD, 25));
//		
//		productoJuguete = new JLabel ("PRODUCTOS PARA EL ENTRETENIMIENTO(Juguetes)");
//		productoJuguete.setBounds(1500,1200,300,25);
//		productoJuguete.setFont(new Font("Arial", Font.BOLD, 25));
//		
//		productoRopa = new JLabel ("PRODUCTOS PARA LA MODA");
//		productoRopa.setBounds(1500,1200,300,25);
//		productoRopa.setFont(new Font("Arial", Font.BOLD, 25));
//		
//		productoElectro = new JLabel ("PRODUCTOS ELECTRICOS");
//		productoElectro.setBounds(1500,1200,300,25);
//		productoElectro.setFont(new Font("Arial", Font.BOLD, 25));
//		
//		productoPapeleria = new JLabel ("PRODUCTOS DE PAPELERIA");
//		productoPapeleria.setBounds(1500,1200,300,25);
//		productoPapeleria.setFont(new Font("Arial", Font.BOLD, 25));
//		
//		productoRecomend = new JLabel ("PRODUCTOS RECOMENDADOS POR TEMU :)");
//		productoRecomend.setBounds(1500,1200,300,25);
//		productoRecomend.setFont(new Font("Arial", Font.BOLD, 25));

//		add(productoCocina);
//		add(productoJuguete);
//		add(productoRopa);
//		add(productoElectro);
//		add(productoPapeleria);
//		add(productoRecomend);
	}

	protected void paintComponent(Graphics g) {
		super.paintComponent(g);

		if (imagenBanio != null) {
			g.drawImage(imagenBanio, 50, 100, 100, 100, this);
		}
	}

	public JLabel getProductoBanio() {
		return productoBanio;
	}

	public void setProductoBanio(JLabel productoBanio) {
		this.productoBanio = productoBanio;
	}

	public JLabel getProductoCocina() {
		return productoCocina;
	}

	public void setProductoCocina(JLabel productoCocina) {
		this.productoCocina = productoCocina;
	}

	public JLabel getProductoJuguete() {
		return productoJuguete;
	}

	public void setProductoJuguete(JLabel productoJuguete) {
		this.productoJuguete = productoJuguete;
	}

	public JLabel getProductoRopa() {
		return productoRopa;
	}

	public void setProductoRopa(JLabel productoRopa) {
		this.productoRopa = productoRopa;
	}

	public JLabel getProductoElectro() {
		return productoElectro;
	}

	public void setProductoElectro(JLabel productoElectro) {
		this.productoElectro = productoElectro;
	}

	public JLabel getProductoPapeleria() {
		return productoPapeleria;
	}

	public void setProductoPapeleria(JLabel productoPapeleria) {
		this.productoPapeleria = productoPapeleria;
	}

	public JLabel getProductoRecomend() {
		return productoRecomend;
	}

	public void setProductoRecomend(JLabel productoRecomend) {
		this.productoRecomend = productoRecomend;
	}

	public int getANCHO_PANEL() {
		return ANCHO_PANEL;
	}

	public int getALTO_PANEL() {
		return ALTO_PANEL;
	}

}
