package co.edu.unbosque.view;

import java.awt.*;

import javax.swing.*;

public class PanelPrincipal extends JPanel {

	private JCheckBox checkEspañol, checkIngles;
	private JLabel seleccionarIdioma, saludo;
	private Image logo;
	private JButton ingresar;

	public PanelPrincipal() {

		setBackground(new Color(255, 109, 0));
		setSize(550, 550);
		setLayout(null);

		seleccionarIdioma = new JLabel("Select your language");
		checkEspañol = new JCheckBox("Spanish");
		checkIngles = new JCheckBox("English");
		saludo = new JLabel("Welcome to TEMU!");
		ingresar = new JButton("Get Order");
		logo = new ImageIcon(getClass().getResource("/recursos/TEMU.png")).getImage();

		saludo.setBounds(40, 120, 300, 25);
		saludo.setFont(new Font("Arial", Font.BOLD, 25));
		saludo.setForeground(Color.white);

		ingresar.setBounds(50, 180, 200, 40);

		seleccionarIdioma.setBounds(90, 250, 200, 25);
		seleccionarIdioma.setForeground(Color.white);

		checkEspañol.setBounds(110, 280, 80, 25);
		checkEspañol.setForeground(Color.white);
		checkEspañol.setBackground(Color.DARK_GRAY);

		checkIngles.setBounds(110, 310, 80, 25);
		checkIngles.setForeground(Color.white);
		checkIngles.setBackground(Color.DARK_GRAY);

		add(seleccionarIdioma);
		add(checkEspañol);
		add(checkIngles);
		add(saludo);
		add(ingresar);
	}

	protected void paintComponent(Graphics g) {
		super.paintComponent(g);

		if (logo != null) {
			g.drawImage(logo, 220, 50, 380, 350, this);
		} else {

		}
	}

	public JCheckBox getCheckEspañol() {
		return checkEspañol;
	}

	public void setCheckEspañol(JCheckBox checkEspañol) {
		this.checkEspañol = checkEspañol;
	}

	public JCheckBox getCheckIngles() {
		return checkIngles;
	}

	public void setCheckIngles(JCheckBox checkIngles) {
		this.checkIngles = checkIngles;
	}

	public JLabel getSeleccionarIdioma() {
		return seleccionarIdioma;
	}

	public void setSeleccionarIdioma(JLabel seleccionarIdioma) {
		this.seleccionarIdioma = seleccionarIdioma;
	}

	public JLabel getSaludo() {
		return saludo;
	}

	public void setSaludo(JLabel saludo) {
		this.saludo = saludo;
	}

	public Image getLogo() {
		return logo;
	}

	public void setLogo(Image logo) {
		this.logo = logo;
	}

	public JButton getIngresar() {
		return ingresar;
	}

	public void setIngresar(JButton ingresar) {
		this.ingresar = ingresar;
	}

}
