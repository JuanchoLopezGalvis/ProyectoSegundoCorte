package co.edu.unbosque.view;

import java.awt.Color;

import javax.swing.*;

public class PanelSeleccionarIdioma extends JPanel {

	private JLabel idioma;
	private JCheckBox checkEspañol, checkIngles;
	private JButton volver;

	public PanelSeleccionarIdioma() {

		setBackground(Color.LIGHT_GRAY);
		setBounds(0, 0, 300, 300);
		setLayout(null);

		idioma = new JLabel("Select your lenguage");
		idioma.setBounds(60, 10, 150, 25);
		idioma.setForeground(Color.white);

		checkEspañol = new JCheckBox("Spanish");
		checkEspañol.setBounds(80, 40, 80, 25);
		checkEspañol.setForeground(Color.white);
		checkEspañol.setBackground(Color.LIGHT_GRAY);

		checkIngles = new JCheckBox("English");
		checkIngles.setBounds(80, 80, 80, 25);
		checkIngles.setForeground(Color.white);
		checkIngles.setBackground(Color.LIGHT_GRAY);

		volver = new JButton("Back");
		volver.setBounds(50, 130, 150, 40);
		volver.setBackground(Color.DARK_GRAY);
		volver.setForeground(Color.white);

		add(idioma);
		add(checkEspañol);
		add(checkIngles);
		add(volver);
	}

	public JLabel getIdioma() {
		return idioma;
	}

	public void setIdioma(JLabel idioma) {
		this.idioma = idioma;
	}

	public JCheckBox getCheckEspañol() {
		return checkEspañol;
	}

	public void setCheckEspañol(JCheckBox checkEspañol) {
		this.checkEspañol = checkEspañol;
	}

	public JCheckBox getCheckIngles() {
		return checkIngles;
	}

	public void setCheckIngles(JCheckBox checkIngles) {
		this.checkIngles = checkIngles;
	}

	public JButton getVolver() {
		return volver;
	}

	public void setVolver(JButton volver) {
		this.volver = volver;
	}
	

}
