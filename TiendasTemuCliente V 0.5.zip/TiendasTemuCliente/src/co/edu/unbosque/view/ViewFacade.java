package co.edu.unbosque.view;

public class ViewFacade {

	private VentanaPrincipal vp;
	private VentanaProducto vpr;
	private VentanaSeleccionarIdioma vsi;
	private VentanaProductoBanio vpb;
	private VentanaProductoCocina vpc;
	private VentanaProductoJuguete vpj;
	private VentanaProductoRopa vpro;
	private VentanaProductoElectro vpe;
	private VentanaProductoPapeleria vpp;
	private VentanaProductoRecomend vpre;

	public ViewFacade() {
		vp = new VentanaPrincipal();
		vpr = new VentanaProducto();
		vsi = new VentanaSeleccionarIdioma();
		vpb = new VentanaProductoBanio();
		vpc = new VentanaProductoCocina();
		vpj = new VentanaProductoJuguete();
		vpro = new VentanaProductoRopa();
		vpe = new VentanaProductoElectro();
		vpp = new VentanaProductoPapeleria();
		vpre = new VentanaProductoRecomend();
	}

	public VentanaPrincipal getVp() {
		return vp;
	}

	public void setVp(VentanaPrincipal vp) {
		this.vp = vp;
	}

	public VentanaProducto getVpr() {
		return vpr;
	}

	public void setVpr(VentanaProducto vpr) {
		this.vpr = vpr;
	}

	public VentanaSeleccionarIdioma getVsi() {
		return vsi;
	}

	public void setVsi(VentanaSeleccionarIdioma vsi) {
		this.vsi = vsi;
	}

	public VentanaProductoBanio getVpb() {
		return vpb;
	}

	public void setVpb(VentanaProductoBanio vpb) {
		this.vpb = vpb;
	}

	public VentanaProductoCocina getVpc() {
		return vpc;
	}

	public void setVpc(VentanaProductoCocina vpc) {
		this.vpc = vpc;
	}

	public VentanaProductoJuguete getVpj() {
		return vpj;
	}

	public void setVpj(VentanaProductoJuguete vpj) {
		this.vpj = vpj;
	}

	public VentanaProductoRopa getVpro() {
		return vpro;
	}

	public void setVpro(VentanaProductoRopa vpro) {
		this.vpro = vpro;
	}

	public VentanaProductoElectro getVpe() {
		return vpe;
	}

	public void setVpe(VentanaProductoElectro vpe) {
		this.vpe = vpe;
	}

	public VentanaProductoPapeleria getVpp() {
		return vpp;
	}

	public void setVpp(VentanaProductoPapeleria vpp) {
		this.vpp = vpp;
	}

	public VentanaProductoRecomend getVpre() {
		return vpre;
	}

	public void setVpre(VentanaProductoRecomend vpre) {
		this.vpre = vpre;
	}

}
