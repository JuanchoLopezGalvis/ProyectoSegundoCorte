package co.edu.unbosque.view;

import java.awt.Image;

import javax.swing.*;

public class VentanaProducto extends JFrame {

	private PanelProducto pp;
	private JMenu menuCarrito, menuIdioma, menuSalir, menuCategorias, menuDescuentos;
	private JMenuItem productoTodo, productoBanio, productoCocina, productoJuguete, productoRopa, productoElectro,
			productoPapeleria, productoRecomend;
	private JMenuBar barraMenu;
	private JLabel txt, descImagen;
	private JScrollPane barra;
	private ImageIcon icon;
	private Image tamañoOriginal;
	private Image tamañoEscalado;
	private ImageIcon iconoEscalado;

	public VentanaProducto() {
		pp = new PanelProducto();
		setSize(1250, 650);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setResizable(false);
		setTitle("Productos");
		setLayout(null);

		barraMenu = new JMenuBar();
		menuCarrito = new JMenu("Shooping cart");
		menuCarrito.setIcon(asignarIcono(25, 25, "src/recursos/CARRITO.png"));

		menuIdioma = new JMenu("Change idiom");
		menuIdioma.setIcon(asignarIcono(25, 25, "src/recursos/IDIOMA.png"));

		menuSalir = new JMenu("Exit");
		menuSalir.setIcon(asignarIcono(25, 25, "src/recursos/EXIT.png"));

		menuCategorias = new JMenu("Categories");

		menuDescuentos = new JMenu("For sale");
		menuDescuentos.setIcon(asignarIcono(25, 25, "src/recursos/DESCUENTO.png"));

		productoTodo = new JMenuItem("All");
		productoTodo.setIcon(asignarIcono(15, 15, "src/recursos/TODOS.png"));

		productoBanio = new JMenuItem("Bathroom");
		productoBanio.setIcon(asignarIcono(18, 18, "src/recursos/BAÑO.png"));

		productoCocina = new JMenuItem("Kitchen");
		productoCocina.setIcon(asignarIcono(18, 18, "src/recursos/COCINA.png"));

		productoJuguete = new JMenuItem("Toys");
		productoJuguete.setIcon(asignarIcono(18, 18, "src/recursos/JUGUETE.png"));

		productoRopa = new JMenuItem("Clothing");
		productoRopa.setIcon(asignarIcono(18, 18, "src/recursos/ROPA.png"));

		productoElectro = new JMenuItem("Electronics");
		productoElectro.setIcon(asignarIcono(18, 18, "src/recursos/ELECTRO.png"));

		productoPapeleria = new JMenuItem("Stationery");
		productoPapeleria.setIcon(asignarIcono(18, 18, "src/recursos/PAPELERIA.png"));

		productoRecomend = new JMenuItem("Recommended by Temu");
		productoRecomend.setIcon(asignarIcono(18, 18, "src/recursos/RECOMEND.png"));

		menuCategorias.add(productoTodo);
		menuCategorias.add(productoBanio);
		menuCategorias.add(productoCocina);
		menuCategorias.add(productoJuguete);
		menuCategorias.add(productoRopa);
		menuCategorias.add(productoElectro);
		menuCategorias.add(productoPapeleria);
		menuCategorias.add(productoRecomend);

		barraMenu.add(menuCarrito);
		barraMenu.add(menuIdioma);
		barraMenu.add(menuCategorias);
		barraMenu.add(menuDescuentos);
		barraMenu.add(menuSalir);
		setJMenuBar(barraMenu);

		barra = new JScrollPane(pp);
		barra.setBounds(0, 0, 1240, 650);
		barra.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		add(barra);
	}

	public ImageIcon asignarIcono(int alto, int ancho, String ruta) {
		icon = new ImageIcon(ruta);
		tamañoOriginal = icon.getImage();
		tamañoEscalado = tamañoOriginal.getScaledInstance(ancho, alto, Image.SCALE_SMOOTH);
		iconoEscalado = new ImageIcon(tamañoEscalado);
		return iconoEscalado;

	}

	public PanelProducto getPp() {
		return pp;
	}

	public void setPp(PanelProducto pp) {
		this.pp = pp;
	}

	public JMenu getMenuCarrito() {
		return menuCarrito;
	}

	public void setMenuCarrito(JMenu menu1) {
		this.menuCarrito = menu1;
	}

	public JMenu getMenuIdioma() {
		return menuIdioma;
	}

	public void setMenuIdioma(JMenu menu2) {
		this.menuIdioma = menu2;
	}

	public JMenu getMenuSalir() {
		return menuSalir;
	}

	public void setMenuSalir(JMenu menu3) {
		this.menuSalir = menu3;
	}

	public JMenuBar getBarraMenu() {
		return barraMenu;
	}

	public void setBarraMenu(JMenuBar barra) {
		this.barraMenu = barra;
	}

	public JMenu getMenuCategorias() {
		return menuCategorias;
	}

	public void setMenuCategorias(JMenu menuCategorias) {
		this.menuCategorias = menuCategorias;
	}

	public JMenu getMenuDescuentos() {
		return menuDescuentos;
	}

	public void setMenuDescuentos(JMenu menuDescuentos) {
		this.menuDescuentos = menuDescuentos;
	}

	public JMenuItem getProductoHogar() {
		return productoBanio;
	}

	public void setProductoHogar(JMenuItem productoHogar) {
		this.productoBanio = productoHogar;
	}

	public JMenuItem getProductoTodos() {
		return productoTodo;
	}

	public void setProductoTodos(JMenuItem productoTodos) {
		this.productoTodo = productoTodos;
	}

	public JMenuItem getProductoBanio() {
		return productoBanio;
	}

	public void setProductoBanio(JMenuItem productoBanio) {
		this.productoBanio = productoBanio;
	}

	public JMenuItem getProductoCocina() {
		return productoCocina;
	}

	public void setProductoCocina(JMenuItem productoCocina) {
		this.productoCocina = productoCocina;
	}

	public JMenuItem getProductoJuguete() {
		return productoJuguete;
	}

	public void setProductoJuguete(JMenuItem productoJuguete) {
		this.productoJuguete = productoJuguete;
	}

	public JMenuItem getProductoRopa() {
		return productoRopa;
	}

	public void setProductoRopa(JMenuItem productoRopa) {
		this.productoRopa = productoRopa;
	}

	public JMenuItem getProductoElectro() {
		return productoElectro;
	}

	public void setProductoElectro(JMenuItem productoElectro) {
		this.productoElectro = productoElectro;
	}

	public JMenuItem getProductoPapeleria() {
		return productoPapeleria;
	}

	public void setProductoPapeleria(JMenuItem productoPapeleria) {
		this.productoPapeleria = productoPapeleria;
	}

	public JMenuItem getProductoRecomend() {
		return productoRecomend;
	}

	public void setProductoRecomend(JMenuItem productoRecomend) {
		this.productoRecomend = productoRecomend;
	}

	public JScrollPane getBarra() {
		return barra;
	}

	public void setBarra(JScrollPane barra) {
		this.barra = barra;
	}

	public ImageIcon getIcon() {
		return icon;
	}

	public void setIcon(ImageIcon icon) {
		this.icon = icon;
	}

	public Image getTamañoOriginal() {
		return tamañoOriginal;
	}

	public void setTamañoOriginal(Image tamañoOriginal) {
		this.tamañoOriginal = tamañoOriginal;
	}

	public Image getTamañoEscalado() {
		return tamañoEscalado;
	}

	public void setTamañoEscalado(Image tamañoEscalado) {
		this.tamañoEscalado = tamañoEscalado;
	}

	public ImageIcon getIconoEscalado() {
		return iconoEscalado;
	}

	public void setIconoEscalado(ImageIcon iconoEscalado) {
		this.iconoEscalado = iconoEscalado;
	}

}
