package co.edu.unbosque.model;

public class ProductoHogarBanio {
  
//Faltan artributos
  //descubriendi
  //Esttoy muy cerca de lograrlo
	
  private String excelente;
}
