package co.edu.unbosque.view;

import javax.swing.JPanel;

public class PanelListarProductoHogarBanio extends JPanel{

}
