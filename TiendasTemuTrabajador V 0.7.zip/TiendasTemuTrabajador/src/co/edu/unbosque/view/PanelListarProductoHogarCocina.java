package co.edu.unbosque.view;

import javax.swing.JPanel;

public class PanelListarProductoHogarCocina extends JPanel{

}
