package co.edu.unbosque.view;

import javax.swing.JPanel;

public class PanelActualizarProductoOcioRopa extends JPanel{

}
