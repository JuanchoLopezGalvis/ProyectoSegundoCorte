/**
 * 
 */
/**
 * 
 */
module TiendasTemuTrabajador {
	requires java.desktop;
}