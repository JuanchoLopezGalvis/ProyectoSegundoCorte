package co.edu.unbosque.view;

import javax.swing.JPanel;

public class PanelEliminarProductoOficinaPapeleria extends JPanel{

}
