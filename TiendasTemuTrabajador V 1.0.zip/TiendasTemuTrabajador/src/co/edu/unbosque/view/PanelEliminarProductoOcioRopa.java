package co.edu.unbosque.view;

import javax.swing.JPanel;

public class PanelEliminarProductoOcioRopa extends JPanel{

}
