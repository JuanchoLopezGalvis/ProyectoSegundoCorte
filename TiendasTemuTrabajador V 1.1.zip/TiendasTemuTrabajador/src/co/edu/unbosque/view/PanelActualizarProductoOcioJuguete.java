package co.edu.unbosque.view;

import javax.swing.JPanel;

public class PanelActualizarProductoOcioJuguete extends JPanel{

}
